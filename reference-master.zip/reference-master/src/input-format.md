# Input format

Rust input is interpreted as a sequence of Unicode code points encoded in UTF-8.
